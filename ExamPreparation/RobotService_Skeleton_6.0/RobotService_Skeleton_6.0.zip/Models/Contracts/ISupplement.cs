﻿namespace RobotService.Models.Contracts
{
    public interface ISupplement
    {
        public int InterfaceStandard { get; }
        public int BatteryUsage { get; }
    }
}
