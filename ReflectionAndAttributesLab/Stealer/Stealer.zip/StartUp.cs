﻿using Stealer;

Spy spy = new();
string result = spy.RevealGettersAndSetters("Stealer.Hacker");
Console.WriteLine(result);