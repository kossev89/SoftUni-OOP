﻿using Stealer;

Spy spy = new();
string result = spy.AnalyzeAccessModifiers("Stealer.Hacker");
Console.WriteLine(result);